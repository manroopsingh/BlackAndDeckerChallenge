package com.example.user.bndchallenge.solution1.food;

/**
 * Created by user on 9/29/17.
 */

public class Meat extends Food {

    public Meat() {
        super(Food.MEAT);
    }
}
