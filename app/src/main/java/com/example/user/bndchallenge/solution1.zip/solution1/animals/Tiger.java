package com.example.user.bndchallenge.solution1.animals;


import com.example.user.bndchallenge.solution1.jungle.Jungle;

/**
 * Created by user on 9/29/17.
 */

public class Tiger extends Animal {


    public Tiger(Jungle jungle) {
        super(Animal.TIGER, jungle);
    }


}
