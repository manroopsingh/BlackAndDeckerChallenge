package com.example.user.bndchallenge.solution1.animals;


import com.example.user.bndchallenge.solution1.jungle.Jungle;

/**
 * Created by user on 9/29/17.
 */

public class Snake extends Animal {


    public Snake(Jungle jungle) {
        super(Animal.SNAKE, jungle);

    }

}
