package com.example.user.bndchallenge.solution1.food;


/**
 * Created by user on 9/29/17.
 */

public class Fish extends Food {

    public Fish() {
        super(Food.FISH);
    }
}
