package com.example.user.bndchallenge.solution1.food;


/**
 * Created by user on 9/29/17.
 */

public class Bugs extends Food {

    public Bugs() {
        super(Food.BUGS);
    }


}
