package com.example.user.bndchallenge.solution1.food;

/**
 * Created by user on 9/29/17.
 */

public class Grain extends Food {

    public Grain() {
        super(Food.GRAIN);
    }
}
