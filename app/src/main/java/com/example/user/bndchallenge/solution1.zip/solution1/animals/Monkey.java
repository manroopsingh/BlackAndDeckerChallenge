package com.example.user.bndchallenge.solution1.animals;


import com.example.user.bndchallenge.solution1.jungle.Jungle;

/**
 * Created by user on 9/29/17.
 */

public class Monkey extends Animal{

    public Monkey(Jungle jungle) {
        super(Animal.MONKEY, jungle);
    }



}
